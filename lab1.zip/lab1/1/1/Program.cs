﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Лаб1
{
    class Program
    {
        static void Main(string[] args)
        {
            double a, b, c, D, x, x1, x2;
            Console.WriteLine("Введите коэффициенты:");
            a = ReadDouble("a: ");
            b = ReadDouble("b: ");
            c = ReadDouble("c: ");
            if ((a == 0 && b == 0 && c == 0))
            {
                Console.WriteLine("Бесконечное множество корней");

            }
            else if (a == 0 && b == 0)
            {
                Console.WriteLine("Корней нет");
            }
            else if (a == 0)
            {
                x = -c / b;
                Console.WriteLine("x = {0}", x);

            }
            else if (b == 0)
            {
                if ((-c / a) >= 0)
                {
                    x1 = Math.Sqrt(-c / a);
                    x2 = -Math.Sqrt(-c / a);
                    Console.WriteLine("x1 = {0}", x1);
                    Console.WriteLine("x2 = {0}", x2);
                }
                else Console.WriteLine("Корней нет");

            }
            else
            {
                D = b * b - 4 * a * c;
                if (D > 0)
                {
                    x1 = (-b + Math.Sqrt(D)) / (2 * a);
                    x2 = (-b - Math.Sqrt(D)) / (2 * a);
                    Console.WriteLine("x1 = {0}", x1);
                    Console.WriteLine("x2 = {0}", x2);
                }
                else if (D < 0)
                {
                    Console.WriteLine("Нет действительных корней");
                }
                else if (D == 0)
                {
                    x = -b / (2 * a);
                    Console.WriteLine("x = {0}", x);
                }

            }


            Console.ReadKey();
        }
        static double ReadDouble(string message)
        {
            string resultString;
            double resultDouble;
            bool flag;
            do
            {
                Console.Write(message);
                resultString = Console.ReadLine();
                flag = double.TryParse(resultString, out resultDouble);

                if (!flag)
                {
                    Console.WriteLine("Необходимо ввести вещественное число");
                }
            }
            while (!flag);
            return resultDouble;
        }
    }
}